import os , math , time
from sys import argv
import subprocess
unique=[]
dirs= '/disk1' # Папка с плотами для распределения
folder1 = '/disk1/folder1' # Папка с плотами 1
folder2 = '/disk2/folder2' # Папка с плотами 2
dirfiles=[]
n=0
while True:
    #d = os.listdir(dirs)
    #print(d)
    for file in os.listdir(dirs):
       if file.endswith(".plot"):
           dirfiles.append(file)
    print(dirfiles)
    for qqq in  dirfiles:
       if qqq not in unique:
           n+=1
           if len(folder2)-5 > len(folder1) :
               print('ПЕреношу ' + qqq + '  в  :' + str(folder1))
               print((dirs+'/'+qqq+' v '+folder2 + '/' + qqq))
               os.system('sleep 10 && mv '+ dirs+'/'+qqq +' '+ folder1 + '/' + qqq)
               unique.append(qqq)
           else:
               print('ПЕреношу ' + qqq + '  в  :' + str(folder2))
               print((dirs+'/'+qqq +' v '+ folder2 + '/' + qqq))
               os.system('sleep 40 && mv '+ dirs+'/'+qqq +' '+ folder2 + '/' + qqq)
               unique.append(qqq)
               n=0
    time.sleep(10)
    