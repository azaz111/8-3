from time import sleep
from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os , math
from sys import argv
import json
from BIB_API import service_avtoriz , ls_fails_onlly , spisok_fails_q ,folder_po_id , \
           spisok_fails_roditelya,createRemoteFolder , drive_ls ,_is_success
successful = []

service = service_avtoriz()
service2 = service_avtoriz('v2')

def _is_success(id, resp, exception):
    global successful

    if exception is None:
        #print(id)
        #print(resp)
        #print(exception)
        successful.append(resp['id'])


def peremesti_v_odnu(s_iddrive,id_foldnazna):# Все фалы в одну папку
   global successful
   service = service_avtoriz()
   ls_files=ls_fails_onlly(s_iddrive,service)
   print('Сортирую . '+str(len(ls_files)))
   id_foldnazna_iskl=ls_fails_onlly(s_iddrive,service,id_foldnazna) # Создаем Исключения
   successful=[eee.get('id') for eee in id_foldnazna_iskl ]
   parents={}
   for i in ls_files:
       parents[str(i['id'])]=[str(",".join(i['parents']))] # Создаем библиотеку ключей
   
   ls_files=[eee.get('id') for eee in ls_files ]
   while True :
      try:
         ls_files=list(set(ls_files)-set(successful))
         batch = service.new_batch_http_request(callback=_is_success) 
         for i in ls_files[:999]:
            batch.add(service.files().update(fileId=i,
                                    addParents=id_foldnazna,
                                    supportsAllDrives=True, 
                                    removeParents=",".join(parents.get(i)), fields='id, parents'))
         print('Otpravka zaprosa')
         batch.execute()
         sleep(1)
         if len(ls_files) == 0:
            successful=[]
            print('Konec')
            break
      except:
         print('Тут ошибка таймаута')

#if len(drive_ls(service)) == 1 :
#   s_iddrive=drive_ls(service)[0]['id']
#   mud_name=drive_ls(service)[0]['name']
#else:
#   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
#   exit()
s_iddrive=input('vvedi id : ')


id_rodf=createRemoteFolder(service2, 'PLOT' , s_iddrive)
peremesti_v_odnu(s_iddrive,id_rodf)







