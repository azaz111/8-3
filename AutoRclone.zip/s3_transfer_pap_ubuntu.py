import os , math , time
from sys import argv
unique=[]


try:
   for root, dirs, files in os.walk('korzina', topdown = False):
      for name in files:
         unique.append(os.path.join(name))
   print(unique)
   os.chdir(str(os.getcwd()))
except:
   pass

dirs=argv[1] # дериктория плотинга

dirfilesv = os.listdir(dirs)
n=0
while True:
   for ndir in dirfilesv:
      basket=ndir
      
      dirs2=dirs+'/'+ndir
      try:
         dirfiles = os.listdir(dirs2)

         for qqq in  dirfiles:
            if qqq not in unique and os.stat(dirs2+'/'+qqq).st_size > 108650979000:
                n+=1
                time.sleep(5)
                print('запускаю транс  На S3 :' + str(n) + 'в корзину : '+ basket)
                os.system(f'start rclone copy {dirs2}/{qqq} s3:{basket} --s3-disable-checksum -P --transfers 1 --s3-upload-concurrency 8 --s3-chunk-size 50mi -v --log-file /root/rclone.txt')
                unique.append(qqq)
                if len(unique) > 200:
                   unique.pop(0)  
         time.sleep(10)
      except:
         pass
