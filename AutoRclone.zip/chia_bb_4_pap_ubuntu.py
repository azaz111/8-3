import os , time , threading
from argparse import ArgumentParser
from random import choice, randint
try:
   from mem_edit import Process
except:
   pass

try:
   os.system(f'apt install cputool')
   os.system(f'pip install mem-edit')
except:
   pass
from mem_edit import Process





def plot(scolco,dirs,monitorind,cpu):

   try:
      with open(f'/root/basket.txt', "r") as filef:
         basket=filef.read()[:-1]
   except:
      basket=input('Введи имя корзины : ')
      '''Создаем файл с именем корзины '''
      with open(f'/root/basket.txt', "w") as filef:
         filef.write(basket)
      #os.system(f'start rclone mkdir s3:{basket}')
   print(basket)

   
   n=0
   while True:
      if n==4:
         n=0
      n+=1
      dirs1=dirs+basket+'-'+str(n)
      print(dirs1)
      try:
         os.system(f'mkdir {dirs1}')
         os.system(f'rclone mkdir s3:{basket}-{n}')
      except:
         pass
   
      print('Буду плотить  : '+ str(int(scolco) - len(os.listdir(dirs1))))
      if len(os.listdir(dirs1)) < int(scolco) :
         nzap=int(scolco) - len(os.listdir(dirs1))
         time.sleep(5)
         print('Запускаю Плотинг с ограничением нагрузки ')
         zap_namber=f'cd && ./bladebit/build/bladebit -n {nzap} -f b8e1d57e3e2dbb40ac8f2b257b762d05fcfc5b79c32a22255424644b7d183daa7c454624783f2d959c02eb1d2a4ba3a3 -p 91ea997633345082b15f83b957449180037030b6b7485f07ed4ee7558d08d3efbccf2c3d68ba724f5b3a8281a0055e27 {dirs1}'
         os.system(zap_namber)   

      
      else:
         print('\r Статуст : {}'.format('Ожидаю  передачи '), end='')  
      time.sleep(5)


if __name__ == '__main__':
    parse = ArgumentParser(description=' Включаем плоттер в зависимрсти от заданного количества .')
    parse.add_argument('--scolco','-s', default='4', help='Укажи количество плотов в папке .')
    parse.add_argument('--pach','-p', default='/disk1', help='Путь в который плотить .')
    parse.add_argument('--monitorind','-m', default='/disk1', help='Путь по которому мониторить .')
    parse.add_argument('--zagruzka' ,'-cpu ', type=int , default='10000', help='Лимит загрузки CPU .')
    args = parse.parse_args()
    plot(
       scolco=args.scolco,
       dirs=args.pach,
       monitorind=args.monitorind,
       cpu=args.zagruzka,
    )

