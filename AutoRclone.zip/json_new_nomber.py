import os
path='accounts'
i = 1
for filename in os.listdir(path):
    os.rename(os.path.join(path,filename), os.path.join(path,str(i)+'.json'))
    i = i +1 