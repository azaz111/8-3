import time , os
from sys import argv
text=argv[1]

try:
   with open(f'/root/basket.txt', "r") as filef:
      text=filef.read()
except:
   text='Незнакомец'

try:
   puti=argv[1]
except:
   puti = False

def schet_plot(puti):
   sub = ": Copied (new)"  
   try:
      sfa = open(puti, "r") 
      str2 = sfa.read()
      rcl2= str2.count(sub)
      sfa.close()
   except OSError:
      print(f"Nenaideno rclone2.log'")
      rcl2=0
   return rcl2
   

def bot(mas , komu):
    #komu=[183787479,292529642]
    os.system('pip install aiogram')
    from aiogram.utils import executor
    from aiogram import Bot, Dispatcher
    bot = Bot(token='5256993370:AAFDtPpjGOvz1ZvsA-On2Bhzh3HGb53R7Gs')
    dp = Dispatcher(bot)
   
    async def somefunc(masge):
        for komu_m in komu:
           await bot.send_message(komu_m, masge)
     
    executor.start(dp, somefunc(mas))

text1=text
while True:
   if puti != False:
      print('esti')
      text1 = text + ' peredano : ' + str(schet_plot(puti))
   bot(text1,[183787479,292529642])
   time.sleep(300)
