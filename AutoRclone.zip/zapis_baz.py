import os ,time, datetime
try:
    import paramiko
except:
    os.system('pip install paramiko')
    time.sleep(30)

from sys import argv

baza=argv[1] # указываем скрипт базы на сервере

def command_toserv(com,host,password):# Отправляем команду в терминал убунту:
    username='root'
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=host, username=username, password=password)  
    result = {}
    for q in com :
        time.sleep(2)
        stdin, stdout, stderr =ssh.exec_command(f'{q}\n')
    output=""    
    try:
        rezul=stdout.read()
        output += rezul
        result[com] = output
    except:
        pass
    print(result)
    return rezul

def ipp():
   import socket
   s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
   s.connect(("8.8.8.8", 80))
   return s.getsockname()[0]

def schet_plot(puti):
   sub = ": Deleted"  
   try:
      sfa = open(puti, "r") 
      str2 = sfa.read()
      rcl2= str2.count(sub)
      sfa.close()
   except OSError:
      print(f"Nenaideno rclone2.log'")
      rcl2=0
   return rcl2
while True:
    try:
        data_list=[]
        
        t2 = os.path.getmtime('/root/chia-plotter')
        t = time.time()
        t3 = t-t2
        
        vseti = str(datetime.timedelta(seconds = int(t3))) 
        print(vseti)
        try:
            vseti = vseti.replace(' ', ':')
            vseti = vseti.replace(',', '')
        except:
            pass
    
        
        
        
        data_list.append(ipp()) # добавили айпишку 
        data_list.append(vseti) # подсчитали время 
        try:
           data_list.append(schet_plot('/root/rclone1.log')) # подсчитали количество плотов
        except:
           data_list.append(0) 
        data_list.append(t)
    
        try:
           data_list.append(str(int(t3/60/data_list[2]))+'-m/plot') # подсчитали количество плотов
        except:
           data_list.append(0) 
        print(data_list[2])
        print(data_list[3])
        print(data_list[4])
    
        host = '149.248.8.216'
        password='XUVLWMX5TEGDCHDU'
        
    
    
        print(command_toserv([f'python3 {baza} {data_list[0]} {data_list[1]} {data_list[2]} {data_list[3]} {data_list[4]}'],host,password))
        time.sleep(360)
    except:
        print('OSHIBKA vo VREMYA CIKLA')
        time.sleep(200)