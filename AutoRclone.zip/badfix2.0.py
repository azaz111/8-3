import os
from time import sleep, time
import conf_bf
from glob import glob
from json import loads
from BIB_API import service_avtoriz
import pymysql , json ,subprocess
from sshtunnel import SSHTunnelForwarder
import time
import pymysql
from sshtunnel import SSHTunnelForwarder
from BIB_API import bot

path=conf_bf.server_name
tabl_json=conf_bf.tabl_json

server = SSHTunnelForwarder(
    ('149.248.8.216', 22),
    ssh_username='root',
    ssh_password='XUVLWMX5TEGDCHDU',
    remote_bind_address=('127.0.0.1', 3306)
)

def getConnection(): 
    # Вы можете изменить параметры соединения.
    connection = pymysql.connect(host='127.0.0.1', port=server.local_bind_port, user='chai_cred',
                      password='Q12w3e4003r!', database='credentals',
                      cursorclass=pymysql.cursors.DictCursor)
    return connection

def _get_token(num=2):
    server.start()
    mybd = getConnection()
    cur = mybd.cursor()
    cur.execute( f"SELECT * FROM {tabl_json} WHERE status = 'True' " ) # запросим все данные  
    rows = cur.fetchall()
    
    try:
       token_j2=json.loads(rows[0]['token_j'])
       with open('token%s.json' % num , 'w') as token:
           json.dump(token_j2,token)
   
       id_cred=rows[0]['id']
       id_progect=rows[0]['id_progect']

       print('Записались  +++ ')
       cur.execute( f"UPDATE {tabl_json} set status = 'False' WHERE id = {id_cred} ") # Обнавление данных
       mybd.commit()
       mybd.close()
    except:
        print('w++++++++++++++++++++++++++++++++')
        bot("НЕТ СВОБОДНЫХ ПРОЕКТОВ" , [292529642,183787479])
    server.stop()
    return id_progect

def download_new_json():
    os.system('rm -R accounts')
    os.system('mkdir accounts')
    id_progect=_get_token()
    while True:
       try:
           proc=subprocess.Popen(['python3', 'multifactory10.py', '--download-keys', id_progect , '--token' , 'token2.json' ])
           proc.wait(timeout=25)
           print('Завершился')
           break
       except subprocess.TimeoutExpired:
           proc.terminate()
           print('Не завершился')
           os.system('rm -R accounts')
           os.system('mkdir accounts')
           process = subprocess.Popen(['python3', 'multifactory.py', '--delete-sas', id_progect ,'--token' , 'token2.json' ])
           process.wait()
           process = subprocess.Popen(['python3', 'multifactory10.py', '--create-sas', id_progect ,'--token' , 'token2.json' ])
           process.wait()
           process = subprocess.Popen(['python3', 'multifactory10.py', '--download-keys', id_progect , '--token' , 'token2.json' ])
           process.wait()

def read_status():

    server.start()
    mybd = getConnection()
    cur = mybd.cursor()
    try:
       cur.execute( f"SELECT * FROM {tabl_json}_STATUS WHERE name_baz = '{path}' " ) # запросим все данные  
       rows = cur.fetchall()
       if rows[0]['status'] == 'True':
           countdown('До запуска -',110)
           cur.execute( f"UPDATE {tabl_json}_STATUS set status = 'False' WHERE  name_baz = '{path}' ") # Обнавление данных
           mybd.commit()
           mybd.close()
           server.stop()
           return True
       else:
           server.stop()
           return False
    except:
      server.stop()
      print('Ошибка работы с базами ' ,end='\r')
      return False
    
def countdown(text='',num_of_secs=10):
   while num_of_secs:
       m, s = divmod(num_of_secs, 60)
       min_sec_format = '{:02d}:{:02d}'.format(m, s)
       print(text + min_sec_format, end='\r')
       time.sleep(1)
       num_of_secs -= 1  

server = SSHTunnelForwarder(
    ('149.248.8.216', 22),
    ssh_username='root',
    ssh_password='XUVLWMX5TEGDCHDU',
    remote_bind_address=('127.0.0.1', 3306)
)

def getConnection(): 
    # Вы можете изменить параметры соединения.
    connection = pymysql.connect(host='127.0.0.1', port=server.local_bind_port, user='chai_cred',
                      password='Q12w3e4003r!', database='credentals',
                      cursorclass=pymysql.cursors.DictCursor)
    return connection

def get_json_baz(list_nomber):
    server.start()
    mybd = getConnection()
    cur = mybd.cursor()
    for l in list_nomber:
        cur.execute( f"SELECT * FROM {tabl_json} WHERE id = {l};" ) # запросим данные id
        data=cur.fetchall()[0]

        #print(len(data))
        #print(data)
        
        with open(f'accounts/{l}.json','w') as fj:
            #print(data['json_data'])
            fj.write(data['json_data'][1:-1])
    mybd.commit()
    mybd.close()
    server.stop()

def pap_mount(name_osnova,nomber_osnova):
   try:
      sleep(2)
      sum_plot=len(os.listdir(f'/{name_osnova}/{nomber_osnova}-1.d'))
      sleep(2)
   except:
      sum_plot=0
   return sum_plot
   
def cikl():
   list_nomber=list(range(conf_bf.osn_serv+1,conf_bf.osn_lim+1))

   """ Обновляем джисоны с архива """
   #print(' Pаботаем с %s' % list_nomber)
   #get_json_baz(list_nomber)
   

   """ Читаем список дисков заносим в переменную """

   #with open('Spisok_drive.txt', 'rb') as t:
   #   sp_drive=t.read().decode('utf-8').split('\n')
#
   #list_drive=[]
   #for rrr in list_nomber :
   #   list_drive.append(sp_drive[rrr - 1])


   """ Привязываем джисоны к дискам """
   #drive=service_avtoriz()
   #accounts_to_add = []
   #path ='accounts'
   #print('Fetching emails')
   #for i in glob('%s/*.json' % path):
   #    accounts_to_add.append(loads(open(i, 'r').read())['client_email'])
#
   #for qqq in list_drive:
   #   for i in accounts_to_add:
   #      try:
   #         drive.permissions().create(fileId=qqq, fields='emailAddress', supportsAllDrives=True, body={
   #             "role": "fileOrganizer",
   #             "type": "user",
   #             "emailAddress": i
   #         }).execute()
   #      except:
   #         print('------- Впоймали косяк с диском ------')
   #   print('Adding')


   """ Монтируем + Проверка """

   schet=0
   x=conf_bf.start_json
   q=0
   #for iii in list_nomber:
   #   name_osnova='osnova'+str(iii)
   #   print(name_osnova + '--  размонт --')
   #   os.system (f'fusermount -uz /{name_osnova}')
      


   for iii in list_nomber:
      name_osnova='osnova'+str(iii)
      print(name_osnova + '---------------')
      #os.system (f'rclone backend set {name_osnova}: -o service_account_file="/root/AutoRclone/accounts/{x+1}.json"')
      #os.system (f'screen -dmS "{name_osnova}" rclone mount {name_osnova}: /{name_osnova} --allow-non-empty --daemon  --multi-thread-streams 1024 --multi-thread-cutoff 128M --network-mode  --vfs-read-chunk-size-limit off --buffer-size 0K --vfs-read-chunk-size 64K --vfs-read-wait 0ms -v')

      x += 1



      if pap_mount(name_osnova,iii) >= 1 :
         print(f'Диск {name_osnova} смонтирован ')
      else:
         print(f'Нет плотов {name_osnova} - , косяк')
         
         with open('Spisok_drive.txt', 'rb') as t:
            sp_drive=t.read().decode('utf-8').split('\n') # СЧИТАТЬ ПОСТОЧНО ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
         download_new_json()
         



         while True:
            schet=schet+1
            sleep(6)
            os.system (f'fusermount -uz /{name_osnova}')
            os.system (f'screen -dmS "{name_osnova}" rclone mount {name_osnova}: /{name_osnova} --allow-non-empty --daemon --multi-thread-streams 1024 --multi-thread-cutoff 128M --network-mode - --vfs-read-chunk-size-limit off --buffer-size 0K --vfs-read-chunk-size 64K --vfs-read-wait 0ms -v')
            print( 'Пытаюсь повторно размонтировать')
            if pap_mount(name_osnova,iii) >= 1 :
               print(' Повторно прокатило')
               schet=0
               break
            if schet == 4:
               schet=0
               break  
   
   print("\033[32m{}\033[0m".format(' ВЫПОЛНЕНО ! Монтирование ЗАВЕРШЕНо ! '))



if __name__ == '__main__':
   while True:
      if read_status() == True :
         print('Приступаю к работе')
         cikl()
      else:
         countdown('Файл не найден джу минуту - ',60)


         
#